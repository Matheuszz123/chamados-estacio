export const firebaseConfig = {
    apiKey: 'AIzaSyB6vRoOzr1FCq4HnVe8OPI7KzIdt1h7e9A',
    authDomain: 'project-sistema-chamados.firebaseapp.com',
    projectId: 'project-sistema-chamados',
    storageBucket: 'project-sistema-chamados.appspot.com',
    messagingSenderId: '247135422359',
    appId: '1:247135422359:web:de75c77d15d58410eb66d2',
    measurementId: 'G-RZ6XE12K5B',
};
